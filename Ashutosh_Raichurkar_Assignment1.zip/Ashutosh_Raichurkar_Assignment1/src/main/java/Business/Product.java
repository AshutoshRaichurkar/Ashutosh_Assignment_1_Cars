/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Raichurkar
 */
public class Product {

private String carName;
private String carColor;
private String carDisc;
private String carModel;
private String carWheels;
private String carDoors;
private String carAvg;
private String carCompany;
private String carSeats;
private String carPrice;
private String carYear;
private String carTs;
private String carLights;
private String carBrakes;
private String carAirBags;
private String carBoot; 
private String Image;

    public String getImage() {
        return Image;
    }

    public void setImage(String Image) {
        this.Image = Image;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getCarColor() {
        return carColor;
    }

    public void setCarColor(String carColor) {
        this.carColor = carColor;
    }

    public String getCarDisc() {
        return carDisc;
    }

    public void setCarDisc(String carDisc) {
        this.carDisc = carDisc;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getCarWheels() {
        return carWheels;
    }

    public void setCarWheels(String carWheels) {
        this.carWheels = carWheels;
    }

    public String getCarDoors() {
        return carDoors;
    }

    public void setCarDoors(String carDoors) {
        this.carDoors = carDoors;
    }

    public String getCarAvg() {
        return carAvg;
    }

    public void setCarAvg(String carAvg) {
        this.carAvg = carAvg;
    }

    public String getCarCompany() {
        return carCompany;
    }

    public void setCarCompany(String carCompany) {
        this.carCompany = carCompany;
    }

    public String getCarSeats() {
        return carSeats;
    }

    public void setCarSeats(String carSeats) {
        this.carSeats = carSeats;
    }

    public String getCarPrice() {
        return carPrice;
    }

    public void setCarPrice(String carPrice) {
        this.carPrice = carPrice;
    }

    public String getCarYear() {
        return carYear;
    }

    public void setCarYear(String carYear) {
        this.carYear = carYear;
    }

    public String getCarTs() {
        return carTs;
    }

    public void setCarTs(String carTs) {
        this.carTs = carTs;
    }

    public String getCarLights() {
        return carLights;
    }

    public void setCarLights(String carLights) {
        this.carLights = carLights;
    }

    public String getCarBrakes() {
        return carBrakes;
    }

    public void setCarBrakes(String carBrakes) {
        this.carBrakes = carBrakes;
    }

    public String getCarAirBags() {
        return carAirBags;
    }

    public void setCarAirBags(String carAirBags) {
        this.carAirBags = carAirBags;
    }

    public String getCarBoot() {
        return carBoot;
    }

    public void setCarBoot(String carBoot) {
        this.carBoot = carBoot;
    }

    
}
